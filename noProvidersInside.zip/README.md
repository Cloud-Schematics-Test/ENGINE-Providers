# myproviders
DO NOT USE! 
This is just for my internal tests.
Official link for the IBM Cloud Terraform provider is https://github.com/IBM-Bluemix/terraform-provider-ibm/releases
